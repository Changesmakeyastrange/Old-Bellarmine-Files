public class Bsum
{
	public static void main ( String args[] )
	{
		int t=0;
			
		for(int x = 58; x >= 24; x--)
		{
			t = t + x;
		}
		System.out.print(t);
	}
}