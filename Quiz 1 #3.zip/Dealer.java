import javax.swing.*;

public class Dealer 
{
	public static void main(String[] args) 
	{
		Shuffle x = new Shuffle();

		x.createhands();
		x.display();
		
		System.exit(0);
	}
}